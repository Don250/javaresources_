/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Util.HibernateUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;


/**
 *
 * @author Donatien
 * @param <K>
 */
public class GenericDao<K> {
    
     Session session = null;
    private final Class<K> type;

    public GenericDao(Class<K> type) {
        this.type = type;
    }

    public Session createSession() {
        session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        return session;
    }

    public void closeSession() {
        session.getTransaction().commit();
        session.close();
    }

    public void save(K obj) {
        createSession().save(obj);
        closeSession();
    }

    public void update(K obj) {
        createSession().update(obj);
        closeSession();
    }

    public void delete(K obj) throws HibernateException {
        createSession().delete(obj);
        closeSession();
    }

    public void deleteBy(String prop, Serializable value) throws HibernateException {
        createSession().createQuery("delete from " + type.getName() + " where " + prop + " = " + value + "").executeUpdate();
        closeSession();
    }

    public void deleteAll(List<K> obj) {
        createSession().delete(obj);
        closeSession();
    }
    
    public K findById(Serializable id) {
        K obj = (K) createSession().get(type, id);
        closeSession();
        return obj;
    }

    public List<K> findByProp(String prop, Serializable value) {
        List<K> results = new ArrayList<>();
//        List<K> obj = createSession().createCriteria(type.getName()).add(Restrictions.eq(prop, value)).list();
        try {
            String hql = "from " + type.getName() + " where " + prop + " ='" + value + "'";
            Session ss = createSession();
            Query query = ss.createQuery(hql);
            results = query.list();

            closeSession();
        } catch (Exception e) {
        }

        return results;

    }

    public K Login(String email, String password) {
        K obj = (K) createSession().createCriteria(type.getName()).add(Restrictions.eq("email", email)).add(Restrictions.eq("password", password)).uniqueResult();
        closeSession();
        return obj;
    }

    public List<K> findAll() {
        List<K> obj = createSession().createCriteria(type.getName()).list();
        closeSession();
        return obj;
    }
}
