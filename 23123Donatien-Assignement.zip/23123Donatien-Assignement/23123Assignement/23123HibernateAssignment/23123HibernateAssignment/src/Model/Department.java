/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Donatien
 */
@Entity
@Table(name = "departments")
public class Department implements Serializable {
    @Id
    @Column(name = "code")
    private String depCode;
    @Column(name = "name")
    private String depName;

    @ManyToOne
    @JoinColumn(name = "faculty_code")
    private Faculty faculty;
    
    @OneToMany(mappedBy = "department")
    private List<Teacher> teachers;
    
    @OneToMany(mappedBy = "department")
    private List<Student> students;
    
    @OneToMany(mappedBy = "department")
    private List<Course> courses;
    
    public Department() {
    }

    public Department(String depCode, String depName, Faculty faculty, List<Teacher> teachers, List<Student> students) {
        this.depCode = depCode;
        this.depName = depName;
        this.faculty = faculty;
        this.teachers = teachers;
        this.students = students;
    }

    public Department(String depCode, String depName, Faculty faculty) {
        this.depCode = depCode;
        this.depName = depName;
        this.faculty = faculty;
    }


    public String getDepCode() {
        return depCode;
    }

    public void setDepCode(String depCode) {
        this.depCode = depCode;
    }

    public String getDepName() {
        return depName;
    }

    public void setDepName(String depName) {
        this.depName = depName;
    }

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

 

    @Override
    public String toString() {
        return "Code: " + depCode + ", depName: " + depName;
    }

    
}
