/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Donatien
 */
@Entity
@Table(name = "fuculties")
public class Faculty implements Serializable {
    @Id
    @Column(name = "code")
    private String facultyCode;
    @Column(name = "name")
    private String facultyName;

    @OneToMany(mappedBy = "faculty",cascade = CascadeType.ALL)
    private List<Department> departments;
    
    @OneToMany(mappedBy = "faculty")
    private List<Teacher> teachers;
    
    @OneToMany(mappedBy = "faculty",cascade = CascadeType.ALL)
    private List<Student> students;
  
    public Faculty() {
    }

    public Faculty(String facultyCode, String facultyName) {
        this.facultyCode = facultyCode;
        this.facultyName = facultyName;
    }

    public Faculty(String facultyCode, String facultyName, List<Department> departments, List<Student> students) {
        this.facultyCode = facultyCode;
        this.facultyName = facultyName;
        this.departments = departments;
        this.students = students;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public String getFacultyCode() {
        return facultyCode;
    }

    public void setFacultyCode(String facultyCode) {
        this.facultyCode = facultyCode;
    }

    public String getFacultyName() {
        return facultyName;
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }

    public List<Department> getDepartments() {
        return departments;
    }

    public void setDepartments(List<Department> departments) {
        this.departments = departments;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    @Override
    public String toString() {
        return "Code: " + facultyCode + ", Name: " + facultyName;
    }
}
