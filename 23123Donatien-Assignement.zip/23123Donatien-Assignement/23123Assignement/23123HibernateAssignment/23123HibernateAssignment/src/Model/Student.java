/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author Donatien
 */
@Entity
@Table(name = "students")
public class Student extends Person implements Serializable{
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "registration",
            joinColumns = {@JoinColumn(name = "course_code")},
            inverseJoinColumns = {@JoinColumn(name = "student_id")})
    private List<Course> registeredCourses;
    
    @ManyToOne
    @JoinColumn(name = "department")
    private Department department;
    
    @ManyToOne
    @JoinColumn(name = "faculty_code")
    private Faculty faculty;

    public Student() {
    }

    public Student(String personId, String personName, String email, String phone) {
        super(personId, personName, email, phone);
    }

    public Student(List<Course> registeredCourses, Department department, Faculty faculty, String personId, String personName, String email, String phone) {
        super(personId, personName, email, phone);
        this.registeredCourses = registeredCourses;
        this.department = department;
        this.faculty = faculty;
    }

    public Student(Department department, Faculty faculty) {
        this.department = department;
        this.faculty = faculty;
    }


    public List<Course> getRegisteredCourses() {
        return registeredCourses;
    }

    public void setRegisteredCourses(List<Course> registeredCourses) {
        this.registeredCourses = registeredCourses;
    }

    public List<Course> getCourseList() {
        return registeredCourses;
    }

    public void setCourseList(List<Course> courseList) {
        this.registeredCourses = courseList;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }
    public void addCourse (Course course){
        registeredCourses.add(course);
    } 
    public void removeCourse(Course course){
 boolean isDeleted= registeredCourses.remove(course);
        System.out.println(isDeleted);
    }
}
