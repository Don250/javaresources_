/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Donatien
 */
@Entity
@Table(name = "teachers")
public class Teacher extends Person implements Serializable{
    private Double salary;
    @ManyToOne
    @JoinColumn(name = "faculty")
    private Faculty faculty;

    @ManyToOne
    @JoinColumn(name = "department")
    private Department department;
    
    @OneToMany(mappedBy = "teacher",cascade = CascadeType.DETACH)
    private List<Course> courses;
    
    public Teacher() {
    }

    public Teacher(String personId, String personName, String email, String phone) {
        super(personId, personName, email, phone);
    }

    public Teacher(Double salary, Faculty faculty, Department department, List<Course> courses, String personId, String personName, String email, String phone) {
        super(personId, personName, email, phone);
        this.salary = salary;
        this.faculty = faculty;
        this.department = department;
        this.courses = courses;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

}
